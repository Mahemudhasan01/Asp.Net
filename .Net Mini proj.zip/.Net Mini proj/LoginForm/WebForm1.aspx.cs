﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

namespace LoginForm
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        //(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\.Net Mini proj\LoginForm\App_Data\Database1.mdf;Integrated Security=True;User Instance=True");
       // SqlCommand com = new SqlCommand();

        //SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\.Net Mini proj\LoginForm\App_Data\Database1.mdf;Integrated Security=True;User Instance=True");  
        protected void Page_Load(object sender, EventArgs e)
        {
            //conn.ConnectionString = "Data source=";
        }

        protected void btnlgn_Click(object sender, EventArgs e)
        {
            //string constr = WebConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
            SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\.Net Mini proj\LoginForm\App_Data\Database1.mdf;Integrated Security=True;User Instance=True");
            try
            {

                //SqlCommand cmd = new SqlCommand("Insert into Login1 User='" + txtName.Text + "' and Password='" + txtpass.Text + "'", conn);
                SqlCommand cmd = new SqlCommand("Select * from Login1 where User='" + txtName.Text + "' and Password='" + txtpass.Text + "", conn);
                conn.Open();
                SqlDataAdapter ads = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ads.Fill(dt);
                
                int i = cmd.ExecuteNonQuery();
               
                if (i==1)
                {
                    Response.Write("<script>alert('Successful in Login')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Error in Login')</script>");
                }
               // DataBind();
                conn.Close();

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {

            //SqlCommand 
        }
    }
}